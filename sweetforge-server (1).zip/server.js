/**
 * server.js — SweetForge Explorer Server (entry point)
 *
 * REST API untuk:
 *   - Authentication (signup, login, JWT)
 *   - Object storage (compatible dengan publishStorage.ts APK client)
 *   - Public game listing (untuk Explorer storefront)
 *
 * DOS Protection:
 *   - Helmet security headers
 *   - Rate limiting per IP (general / login / signup / upload)
 *   - Body size limits
 *   - Path traversal prevention
 *
 * Deploy: Render.com / Railway / Fly.io / VPS
 */

require('dotenv').config();

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

const authRoutes = require('./routes/auth');
const storageRoutes = require('./routes/storage');
const gamesRoutes = require('./routes/games');
const giftsRoutes = require('./routes/gifts');
const adsRoutes = require('./routes/ads');
const notificationsRoutes = require('./routes/notifications');
const { generalLimiter } = require('./middleware/rateLimit');
const { notFound, errorHandler } = require('./middleware/errorHandler');

const PORT = process.env.PORT || 8440;
const CORS_ORIGIN = process.env.CORS_ORIGIN || '*';

// ---------------------------------------------------------------------------
const app = express();

// Trust proxy — penting untuk dapatkan real IP client di Render/Railway
app.set('trust proxy', 1);

// Security headers
app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' },
  contentSecurityPolicy: false, // API server, no CSP needed
}));

// CORS
const corsOptions = {};
if (CORS_ORIGIN === '*') {
  corsOptions.origin = true;
} else {
  corsOptions.origin = CORS_ORIGIN.split(',').map(s => s.trim());
}
app.use(cors(corsOptions));

// Logging (skip in tests)
if (process.env.NODE_ENV !== 'test') {
  app.use(morgan('tiny'));
}

// Body parsers
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));

// General rate limit (DOS protection) — applied to ALL routes
app.use(generalLimiter);

// ---------------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------------

// Health check (no rate limit ideally, but general limiter is fine)
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'sweetforge-server',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
});

// Root info
app.get('/', (req, res) => {
  res.json({
    name: 'SweetForge Explorer Server',
    description: 'REST API for SweetForge game publishing',
    version: '1.0.0',
    endpoints: {
      auth: ['/auth/signup', '/auth/login', '/auth/me'],
      storage: ['/v1/users', '/v1/users/:uid/objects/:key', '/v1/users/:uid/objects?prefix='],
      games: ['/api/games', '/api/games/:userId/:gameId/download'],
      health: ['/health'],
    },
  });
});

// Auth routes (signup/login have stricter rate limits inside)
app.use('/auth', authRoutes);

// Storage routes (compatible dengan APK client)
app.use('/v1', storageRoutes);

// Gift / progress / token system
app.use('/api', giftsRoutes);

// Ads system
app.use('/api/ads', adsRoutes);

// Notifications / inbox
app.use('/api/me/notifications', notificationsRoutes);

// Public games API (untuk Explorer storefront) — mounted after /api/me/* routes
app.use('/api', gamesRoutes);

// ---------------------------------------------------------------------------
// Error handlers (must be last)
// ---------------------------------------------------------------------------
app.use(notFound);
app.use(errorHandler);

// ---------------------------------------------------------------------------
// Start server
// ---------------------------------------------------------------------------
const server = app.listen(PORT, '0.0.0.0', () => {
  console.log('============================================================');
  console.log(`  SweetForge Explorer Server`);
  console.log(`  Listening on http://0.0.0.0:${PORT}`);
  console.log(`  CORS: ${CORS_ORIGIN}`);
  console.log(`  Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log('============================================================');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, closing server...');
  server.close(() => {
    console.log('Server closed.');
    process.exit(0);
  });
});
process.on('SIGINT', () => {
  console.log('SIGINT received, closing server...');
  server.close(() => process.exit(0));
});

module.exports = app;
