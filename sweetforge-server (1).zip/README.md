# 🎮 SweetForge Explorer Server

Server REST API berasingan untuk halaman **Explorer** dalam SweetForge APK.

## 📦 Apa Yang Server Ni Buat?

| Function | Endpoint |
|---|---|
| **Signup akaun baru** | `POST /auth/signup` |
| **Login dapat JWT** | `POST /auth/login` |
| **Info user semasa** | `GET /auth/me` |
| **Register storage user** | `POST /v1/users` |
| **Upload game zip** | `PUT /v1/users/:uid/objects/:key` |
| **Download game zip** | `GET /v1/users/:uid/objects/:key` |
| **List games** | `GET /v1/users/:uid/objects?prefix=` |
| **Delete game** | `DELETE /v1/users/:uid/objects/:key` |
| **Public games listing** (Explorer) | `GET /api/games` |
| **Download game by ID** | `GET /api/games/:userId/:gameId/download` |
| **Health check** | `GET /health` |

---

## 🛡️ Security Features

1. **JWT Authentication** — secret key + 7-day expiry
2. **Password Hashing** — bcrypt (10 rounds)
3. **DOS Protection:**
   - General rate limit: 100 req / 15 min / IP
   - Login rate limit: 10 attempts / 15 min / IP
   - Signup rate limit: 5 attempts / hour / IP
   - Upload rate limit: 10 uploads / min / IP
4. **Body Size Limit** — JSON 1MB, Upload 50MB
5. **Path Traversal Protection** — semua file paths diperiksa
6. **Helmet Security Headers** — XSS, clickjacking, MIME sniffing protection
7. **User Isolation** — user tak boleh akses storage user lain
8. **Storage Quota** — 100MB per user (boleh ubah)

---

## 🚀 Cara Run Secara Percuma (Pilih Satu)

### 🥇 Pilihan A: Render.com (PALING MUDAH — Beginner Friendly)

1. **Download** fail `sweetforge-server.zip` dari folder `download/`
2. **Extract** di komputer kau
3. **Create GitHub repo** baru (public atau private)
4. **Upload** semua fail ke repo tersebut (drag & drop di github.com)
5. Pergi https://render.com → Sign up (Google/GitHub)
6. Klik **"New +"** → **"Web Service"**
7. Pilih repo yang kau upload
8. Render akan auto-detect `render.yaml`. Klik **"Apply"**
9. Tunggu 3-5 minit. Selesai! 🎉

Server URL akan jadi: `https://sweetforge-server-xxxx.onrender.com`

**Free tier Render:**
- 750 jam/bulan (cukup untuk 24/7)
- 512MB RAM
- 1GB persistent disk
- Auto-sleep selepas 15 minit idle (request pertama selepas sleep ambil ~30s)

---

### 🥈 Pilihan B: Railway.app

1. Download + extract `sweetforge-server.zip`
2. Pergi https://railway.app → Sign up dengan GitHub
3. Klik **"New Project"** → **"Deploy from GitHub repo"**
4. Pilih repo kau (upload ke GitHub dulu)
5. Railway auto-detect Dockerfile → deploy
6. Tambah Variables di tab "Variables":
   - `JWT_SECRET` = (generate random string)
   - `NODE_ENV` = production
   - `CORS_ORIGIN` = *
7. Save. Dapat URL: `https://your-app.up.railway.app`

**Free tier Railway:**
- $5 credit/bulan (cukup untuk ~500 jam)
- Tidak auto-sleep
- 500MB persistent volume

---

### 🥉 Pilihan C: Fly.io

1. Install Fly CLI:
   ```bash
   curl -L https://fly.io/install.sh | sh
   ```
2. Login: `flyctl auth login`
3. Dari folder server:
   ```bash
   flyctl launch --no-deploy
   flyctl volumes create sweetforge_data --size 1
   flyctl deploy
   ```
4. Dapat URL: `https://sweetforge-server.fly.dev`

**Free tier Fly.io:**
- 3 shared-cpu VMs (1×256MB)
- 3GB persistent volume
- Tidak auto-sleep

---

### 🔧 Pilihan D: Run Local (untuk test)

```bash
cd sweetforge-server
cp .env.example .env
# Edit .env, tukar JWT_SECRET ke random string
npm install
npm start
```

Server jalan di http://localhost:8440

---

## 📱 Cara Connect APK ke Server

Dalam APK (Capacitor), sebelum import `publishStorage`, set:

```typescript
// src/lib/publishStorage.ts sudah baca ni:
(window as any).__PUBLISH_SERVER_URL__ = 'https://sweetforge-server-xxxx.onrender.com';
(window as any).__PUBLISH_USER_ID__ = 'user-id-dari-login';
```

Atau untuk auto-set globally, edit dalam `src/app/layout.tsx` atau `capacitor.config.ts`.

**Untuk login dari APK**, tambah code ini sebelum publish:

```typescript
// Signup
const r = await fetch('https://your-server.onrender.com/auth/signup', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email, username, password }),
});
const { token, user } = await r.json();
localStorage.setItem('sweetforge:token', token);
localStorage.setItem('sweetforge:userId', user.id);

// Login
const r = await fetch('https://your-server.onrender.com/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email, password }),
});
```

Lepas tu, untuk setiap request storage, hantar header:
```
Authorization: Bearer <token>
```

---

## 🗂️ Struktur Folder

```
sweetforge-server/
├── server.js              # Entry point + middleware setup
├── package.json
├── .env.example           # Environment template
├── .gitignore
├── Dockerfile             # Untuk Railway/Fly.io
├── render.yaml            # Untuk Render.com auto-deploy
│
├── routes/
│   ├── auth.js            # signup, login, me
│   ├── storage.js         # /v1/users/* (compatible APK)
│   └── games.js           # /api/games (public listing)
│
├── middleware/
│   ├── auth.js            # JWT verification
│   ├── rateLimit.js       # DOS protection
│   └── errorHandler.js
│
├── lib/
│   ├── db.js              # SQLite database
│   └── objects.js         # File-based object storage
│
├── scripts/
│   └── test-api.js        # Smoke tests (20 tests)
│
└── data/                  # Persistent storage (gitignored)
    ├── sweetforge.db      # SQLite DB
    └── storage/           # User files (games zip, meta.json)
        └── <userId>/
            └── games/
                ├── abc.meta.json
                └── abc.aegame.zip
```

---

## 🧪 Test Server

```bash
# Pastikan server jalan
npm start

# Run 20 smoke tests
npm test
```

Output:
```
✓ GET /health returns 200
✓ POST /auth/signup returns 201
✓ Signup returns token
...
✓ Path traversal blocked

==================================================
  20 passed, 0 failed
==================================================
```

---

## ⚙️ Environment Variables

| Variable | Default | Function |
|---|---|---|
| `PORT` | `8440` | Port server |
| `JWT_SECRET` | (required) | Secret key untuk sign JWT |
| `JWT_EXPIRES_IN` | `7d` | Token expiry |
| `CORS_ORIGIN` | `*` | Siapa boleh panggil API |
| `USER_QUOTA_BYTES` | `104857600` | Storage quota per user (100MB) |
| `MAX_UPLOAD_BYTES` | `52428800` | Max upload size (50MB) |
| `RATE_LIMIT_GENERAL` | `100` | Req per 15min per IP |
| `RATE_LIMIT_LOGIN` | `10` | Login attempts per 15min |
| `RATE_LIMIT_SIGNUP` | `5` | Signup attempts per hour |
| `DISABLE_ANONYMOUS` | `false` | Set `true` untuk wajibkan login |

---

## ❓ FAQ

**Q: Boleh pakai Firebase Hosting?**
A: TIDAK. Firebase Hosting = static files only. Server ni ada API routes + SQLite database. Kena guna platform yang support Node.js (Render, Railway, Fly.io).

**Q: Kenapa SQLite, bukan Firestore?**
A: SQLite simpler untuk beginner. Bila user base besar (>1000 active users), migrate ke PostgreSQL (Neon/Supabase free tier).

**Q: Data kekal bila server restart?**
A: Ya, kalau guna persistent disk (Render 1GB free, Railway 5GB, Fly.io 3GB). Kalau run locally, data tersimpan di `data/` folder.

**Q: Berapa banyak user free tier boleh support?**
A: ~500-1000 active users dengan 100MB quota setiap seorang. Untuk lebih, upgrade plan atau reduce quota.

**Q: Kalau server tidur (Render free), APK akan error?**
A: Request pertama ambil ~30s untuk wake up. User akan nampak "Loading..." sekejap. Untuk avoid, upgrade ke Render Starter ($7/month) atau guna Railway/Fly.io.

---

## 🆘 Troubleshooting

**Server tak start?**
- Check `.env` wujud dan `JWT_SECRET` panjang (>32 chars)
- Run `npm install` semula
- Lihat log: `cat server.log`

**APK tak boleh connect?**
- Pastikan `CORS_ORIGIN` betul di server
- Test dengan `curl https://your-server.onrender.com/health`
- Pastikan APK set `window.__PUBLISH_SERVER_URL__` sebelum import publishStorage

**Upload fail "Payload too large"?**
- Increase `MAX_UPLOAD_BYTES` di server `.env`
- Atau compress zip game sebelum upload

**Login sentiasa 401?**
- Check token belum expired (default 7 hari)
- Check `JWT_SECRET` sama di semua environment
- Test dengan `npm test` untuk verify server OK
