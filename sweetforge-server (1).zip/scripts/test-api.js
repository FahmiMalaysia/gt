/**
 * scripts/test-api.js — Smoke test untuk verify server jalan dengan betul
 *
 * Run:  node scripts/test-api.js
 * Pastikan server jalan di PORT=8440 sebelum run test ni.
 */

const BASE = process.env.API_URL || 'http://localhost:8440';
const crypto = require('crypto');

async function req(method, path, body, headers = {}) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json', ...headers },
  };
  if (body !== undefined) {
    if (Buffer.isBuffer(body)) {
      opts.body = body;
      opts.headers['Content-Type'] = 'application/octet-stream';
    } else {
      opts.body = JSON.stringify(body);
    }
  }
  const r = await fetch(`${BASE}${path}`, opts);
  const text = await r.text();
  let json = null;
  try { json = JSON.parse(text); } catch {}
  return { status: r.status, json, text, headers: r.headers };
}

let pass = 0, fail = 0;
function check(name, cond, detail = '') {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name} ${detail}`); }
}

// Solve PoW captcha (SHA-256 starts with "0000")
function solvePow(challenge, difficulty = 4) {
  const prefix = '0'.repeat(difficulty);
  for (let nonce = 0; nonce < 10_000_000; nonce++) {
    const hash = crypto.createHash('sha256').update(challenge + String(nonce)).digest('hex');
    if (hash.startsWith(prefix)) return nonce;
  }
  return -1;
}

async function main() {
  console.log(`\nTesting against ${BASE}\n`);

  // === 1. Health ===
  console.log('Health & basic endpoints:');
  const h = await req('GET', '/health');
  check('GET /health returns 200', h.status === 200, `got ${h.status}`);

  // === 2. Captcha challenge ===
  console.log('\nCaptcha (PoW) system:');
  const cap = await req('POST', '/auth/captcha/challenge');
  check('POST /auth/captcha/challenge returns 200', cap.status === 200, `got ${cap.status}`);
  check('Challenge has challenge string', !!cap.json?.challenge);
  check('Challenge has difficulty=4', cap.json?.difficulty === 4, `got ${cap.json?.difficulty}`);

  // === 3. Signup without captcha fails ===
  console.log('\nSignup without captcha (should fail):');
  const noCap = await req('POST', '/auth/signup', {
    email: `test+nocap@${Date.now()}.com`,
    username: `nocap${Date.now()}`,
    password: 'testpass123',
  });
  check('Signup without captcha returns 400', noCap.status === 400, `got ${noCap.status}`);

  // === 4. Solve captcha and signup ===
  console.log('\nSignup with solved captcha:');
  const challenge = cap.json.challenge;
  const nonce = solvePow(challenge, 4);
  check('PoW solved (nonce found)', nonce >= 0, 'solver failed');

  const email = `test+${Date.now()}@example.com`;
  const username = `tester${Date.now().toString().slice(-6)}`;
  const s = await req('POST', '/auth/signup', {
    email, username, password: 'testpass123',
    challenge, nonce,
  });
  check('POST /auth/signup returns 201', s.status === 201, `got ${s.status} ${s.text}`);
  check('Signup returns token', !!s.json?.token);
  const token = s.json?.token;
  const userId = s.json?.user?.id;

  // === 5. Captcha single-use (reuse should fail) ===
  console.log('\nCaptcha single-use (reuse should fail):');
  const reuse = await req('POST', '/auth/signup', {
    email: `test+reuse@${Date.now()}.com`,
    username: `reuse${Date.now()}`,
    password: 'testpass123',
    challenge, nonce,
  });
  check('Reusing captcha returns 403', reuse.status === 403, `got ${reuse.status}`);

  // === 6. Login ===
  console.log('\nLogin:');
  const l = await req('POST', '/auth/login', { email, password: 'testpass123' });
  check('POST /auth/login returns 200', l.status === 200, `got ${l.status} ${l.text}`);
  check('Login returns token', !!l.json?.token);

  // === 7. /auth/me with token ===
  console.log('\nAuth me:');
  const authHeader = { Authorization: `Bearer ${token}` };
  const me = await req('GET', '/auth/me', undefined, authHeader);
  check('GET /auth/me returns 200 with valid token', me.status === 200, `got ${me.status}`);
  check('me.email matches', me.json?.user?.email === email);
  check('me.tokens is 0 (no rewards claimed yet)', me.json?.user?.tokens === 0, `got ${me.json?.user?.tokens}`);

  // === 8. Storage upload (under 10MB quota) ===
  console.log('\nStorage (10MB quota):');
  const testBuffer = Buffer.from(JSON.stringify({ test: true, gameId: 'test-game', title: 'Test' }));
  const up = await req('PUT', `/v1/users/${userId}/objects/games/test.meta.json`, testBuffer, authHeader);
  check('PUT object returns 200', up.status === 200, `got ${up.status} ${up.text}`);

  // === 9. Storage quota check ===
  const meAfterUpload = await req('GET', '/auth/me', undefined, authHeader);
  check('Storage used increased', meAfterUpload.json?.user?.storageUsed > 0, `used=${meAfterUpload.json?.user?.storageUsed}`);
  check('Storage quota is 10MB', meAfterUpload.json?.user?.storageQuota === 10485760, `quota=${meAfterUpload.json?.user?.storageQuota}`);

  // === 10. Gift/Progress system ===
  console.log('\nGift / Progress / Token system:');
  const progState = await req('GET', '/api/me/progress', undefined, authHeader);
  check('GET /api/me/progress returns 200', progState.status === 200, `got ${progState.status}`);
  check('Progress list has 10+ rewards', (progState.json?.progress?.length || 0) >= 10, `got ${progState.json?.progress?.length}`);

  // === 11. Track publish event ===
  console.log('\nTrack events:');
  const track1 = await req('POST', '/api/me/progress/track', {
    eventType: 'publish', refId: 'game-001',
  }, authHeader);
  check('Track publish returns 200', track1.status === 200, `got ${track1.status} ${track1.text}`);
  check('Tracked=true for new event', track1.json?.tracked === true);

  // Dedup test
  const track1dup = await req('POST', '/api/me/progress/track', {
    eventType: 'publish', refId: 'game-001',
  }, authHeader);
  check('Duplicate refId not re-tracked', track1dup.json?.tracked === false && track1dup.json?.reason === 'duplicate');

  // Track 2 more distinct games
  await req('POST', '/api/me/progress/track', { eventType: 'publish', refId: 'game-002' }, authHeader);
  await req('POST', '/api/me/progress/track', { eventType: 'publish', refId: 'game-003' }, authHeader);

  // === 12. Check claimable gifts ===
  console.log('\nCheck claimable gifts:');
  const giftStatus = await req('GET', '/api/me/gift-status', undefined, authHeader);
  check('GET /api/me/gift-status returns 200', giftStatus.status === 200);
  check('hasClaimable=true after 3 publishes', giftStatus.json?.hasClaimable === true, `got ${giftStatus.json?.hasClaimable}`);

  // === 13. Get detailed progress ===
  const progAfter = await req('GET', '/api/me/progress', undefined, authHeader);
  const claimableRewards = (progAfter.json?.progress || []).filter(p => p.claimable);
  console.log(`  Claimable rewards: ${claimableRewards.map(r => r.id).join(', ')}`);
  check('At least 2 claimable rewards (publish_first + publish_3)', claimableRewards.length >= 2, `got ${claimableRewards.length}`);

  // === 14. Claim a reward ===
  console.log('\nClaim reward:');
  const claim = await req('POST', '/api/me/progress/claim', {
    rewardId: 'publish_first_game',
  }, authHeader);
  check('Claim returns 200', claim.status === 200, `got ${claim.status} ${claim.text}`);
  check('Claim returns claimed=true', claim.json?.claimed === true);
  check('Tokens awarded = 1', claim.json?.tokensAwarded === 1);
  check('New balance = 1', claim.json?.newBalance === 1, `got ${claim.json?.newBalance}`);

  // === 15. Cannot claim twice ===
  console.log('\nDouble claim (should fail):');
  const claim2 = await req('POST', '/api/me/progress/claim', {
    rewardId: 'publish_first_game',
  }, authHeader);
  check('Re-claim returns 409', claim2.status === 409, `got ${claim2.status}`);

  // === 16. Cannot claim unmet reward ===
  console.log('\nClaim unmet reward (should fail):');
  const claimUnmet = await req('POST', '/api/me/progress/claim', {
    rewardId: 'play_10_games',
  }, authHeader);
  check('Claim unmet returns 403', claimUnmet.status === 403, `got ${claimUnmet.status}`);

  // === 17. Token balance check ===
  console.log('\nToken balance:');
  const tokens = await req('GET', '/api/me/tokens', undefined, authHeader);
  check('GET /api/me/tokens returns 200', tokens.status === 200);
  check('Balance = 1', tokens.json?.balance === 1, `got ${tokens.json?.balance}`);
  check('Has 1 transaction', (tokens.json?.recentTransactions?.length || 0) === 1);

  // === 18. /api/me after claim ===
  console.log('\n/api/me after claim:');
  const meFinal = await req('GET', '/api/me', undefined, authHeader);
  check('GET /api/me returns 200', meFinal.status === 200);
  check('tokens=1 after claim', meFinal.json?.tokens === 1, `got ${meFinal.json?.tokens}`);
  check('storage quota 10MB', meFinal.json?.storage?.quota === 10485760, `got ${meFinal.json?.storage?.quota}`);
  check('storage used > 0', meFinal.json?.storage?.used > 0);

  // === 19. Anonymous IP-based user ===
  console.log('\nAnonymous IP-based user (no auth):');
  const anonMe = await req('GET', '/api/me');
  check('GET /api/me without token returns 200 (anonymous)', anonMe.status === 200, `got ${anonMe.status}`);
  check('Anonymous user has id starting with ip_', anonMe.json?.user?.id?.startsWith('ip_'), `got ${anonMe.json?.user?.id}`);
  check('Anonymous isAnonymous=true', anonMe.json?.user?.isAnonymous === true);
  check('Anonymous email is null', anonMe.json?.user?.email === null);

  // === 20. Same IP returns same user ===
  const anonMe2 = await req('GET', '/api/me');
  check('Same IP returns same user id', anonMe2.json?.user?.id === anonMe.json?.user?.id);

  // === 21. Path traversal still blocked ===
  console.log('\nSecurity checks:');
  const bad = await req('GET', `/v1/users/${userId}/objects/../../etc/passwd`, undefined, authHeader);
  check('Path traversal blocked', bad.status === 400 || bad.status === 404, `got ${bad.status}`);

  console.log(`\n${'='.repeat(60)}`);
  console.log(`  ${pass} passed, ${fail} failed`);
  console.log(`${'='.repeat(60)}\n`);
  process.exit(fail > 0 ? 1 : 0);
}

main().catch(e => {
  console.error('Test crashed:', e);
  process.exit(1);
});
