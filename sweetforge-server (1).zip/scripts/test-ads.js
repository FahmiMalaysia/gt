/**
 * scripts/test-ads.js — End-to-end test for ads system
 *
 * Flow:
 *   1. Signup user A (developer)
 *   2. Award user A tokens (claim rewards)
 *   3. User A creates ad campaign (pays 8 tokens for 2 clicks)
 *   4. Check has-ads = true
 *   5. User B (anonymous) gets next ad
 *   6. User B reports ad play → user A earns 2 tokens
 *   7. Check user A pending tokens (1min window)
 *   8. Repeat until campaign exhausted
 *   9. Check has-ads = false again
 */

const BASE = process.env.API_URL || 'http://localhost:8440';
const crypto = require('crypto');

async function req(method, path, body, headers = {}) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json', ...headers },
  };
  if (body !== undefined) opts.body = JSON.stringify(body);
  const r = await fetch(`${BASE}${path}`, opts);
  const text = await r.text();
  let json = null;
  try { json = JSON.parse(text); } catch {}
  return { status: r.status, json, text };
}

function solvePow(challenge, difficulty = 4) {
  const prefix = '0'.repeat(difficulty);
  for (let nonce = 0; nonce < 10_000_000; nonce++) {
    const hash = crypto.createHash('sha256').update(challenge + String(nonce)).digest('hex');
    if (hash.startsWith(prefix)) return nonce;
  }
  return -1;
}

let pass = 0, fail = 0;
function check(name, cond, detail = '') {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name} ${detail}`); }
}

async function main() {
  console.log(`\nTesting Ads System against ${BASE}\n`);

  // 1. Signup user A (developer)
  console.log('Setup: Developer signup:');
  const cap = await req('POST', '/auth/captcha/challenge');
  const nonce = solvePow(cap.json.challenge);
  const email = `dev+${Date.now()}@example.com`;
  const username = `dev${Date.now().toString().slice(-6)}`;
  const s = await req('POST', '/auth/signup', {
    email, username, password: 'testpass123',
    challenge: cap.json.challenge, nonce,
  });
  check('Signup returns 201', s.status === 201, `got ${s.status}`);
  const devToken = s.json.token;
  const devId = s.json.user.id;
  const authHeader = { Authorization: `Bearer ${devToken}` };

  // 2. Track publish events to trigger rewards, then claim them for tokens
  console.log('\nAward tokens via publish rewards:');
  await req('POST', '/api/me/progress/track', { eventType: 'publish', refId: 'game-1' }, authHeader);
  await req('POST', '/api/me/progress/track', { eventType: 'publish', refId: 'game-2' }, authHeader);
  await req('POST', '/api/me/progress/track', { eventType: 'publish', refId: 'game-3' }, authHeader);

  // Claim publish_first_game + publish_3_games + daily_login = 3 tokens
  // Wait — that's only 3 tokens. We need 8 for a 2-click campaign.
  // So we need more events. Let's also claim play rewards.
  await req('POST', '/api/me/progress/track', { eventType: 'play', refId: 'play-1' }, authHeader);
  await req('POST', '/api/me/progress/track', { eventType: 'play', refId: 'play-2' }, authHeader);

  // Claim all available
  const progResp = await req('GET', '/api/me/progress', undefined, authHeader);
  const claimable = (progResp.json?.progress || []).filter(p => p.claimable);
  console.log(`  Claimable rewards: ${claimable.map(r => r.id).join(', ')}`);

  let tokensEarned = 0;
  for (const r of claimable) {
    const c = await req('POST', '/api/me/progress/claim', { rewardId: r.id }, authHeader);
    if (c.json?.claimed) tokensEarned += c.json.tokensAwarded;
  }
  console.log(`  Tokens after claiming: ${tokensEarned}`);
  check('Earned at least 3 tokens from rewards', tokensEarned >= 3, `got ${tokensEarned}`);

  // 3. Try to create campaign with insufficient tokens (if < 8)
  console.log('\nCreate ad campaign:');
  const meResp = await req('GET', '/api/me', undefined, authHeader);
  const balance = meResp.json?.tokens || 0;
  console.log(`  Current balance: ${balance} tokens`);

  // If balance < 8, create a 1-click campaign (costs 4 tokens)
  const clicks = balance >= 8 ? 2 : 1;
  const cost = clicks * 4;
  console.log(`  Creating ${clicks}-click campaign (cost: ${cost} tokens)`);

  const campResp = await req('POST', '/api/ads/campaign', {
    gameId: 'test-game-1',
    gameTitle: 'Test Game',
    clicks,
  }, authHeader);
  check('Create campaign returns 201', campResp.status === 201, `got ${campResp.status} ${campResp.text}`);
  check('CampaignId returned', !!campResp.json?.campaignId);
  const campaignId = campResp.json?.campaignId;
  const newBalance = campResp.json?.newBalance;
  check('Balance deducted', newBalance === balance - cost, `expected ${balance - cost}, got ${newBalance}`);

  // 4. Check has-ads = true
  console.log('\nCheck ads availability:');
  const has1 = await req('GET', '/api/ads/has-ads');
  check('has-ads = true after campaign created', has1.json?.hasAds === true, `got ${has1.json?.hasAds}`);

  // 5. User B (anonymous, no auth) gets next ad
  console.log('\nPlayer gets ad:');
  const nextResp = await req('GET', '/api/ads/next');
  check('next returns hasAd=true', nextResp.json?.hasAd === true, `got ${nextResp.json?.hasAd}`);
  check('Ad has campaignId', !!nextResp.json?.campaign?.campaignId);
  check('Ad has adContent (HTML)', !!nextResp.json?.campaign?.adContent);
  check('Ad duration = 5 sec', nextResp.json?.campaign?.durationSec === 5);
  check('Ad gameId matches', nextResp.json?.campaign?.gameId === 'test-game-1');

  // 6. Player reports ad play → dev earns 2 tokens
  console.log('\nPlayer plays ad:');
  const playResp = await req('POST', '/api/ads/play', { campaignId }, {});
  check('Play returns 200', playResp.status === 200, `got ${playResp.status} ${playResp.text}`);
  check('Developer earned 2 tokens', playResp.json?.developerEarned === 2);

  // 7. Check dev pending tokens
  console.log('\nCheck pending tokens:');
  const pendResp = await req('GET', '/api/ads/pending-tokens', undefined, authHeader);
  check('Pending tokens = 2', pendResp.json?.pendingTokens === 2, `got ${pendResp.json?.pendingTokens}`);
  check('Total ad plays = 1', pendResp.json?.totalAdPlays === 1);

  // 8. Check campaign progress
  console.log('\nCheck campaign progress:');
  const campsResp = await req('GET', '/api/ads/campaigns', undefined, authHeader);
  const campaign = campsResp.json?.campaigns?.[0];
  check('Campaign clicks_served = 1', campaign?.clicks_served === 1, `got ${campaign?.clicks_served}`);
  check('Campaign tokens_earned = 2', campaign?.tokens_earned === 2, `got ${campaign?.tokens_earned}`);

  // 9. If multi-click campaign, play again to exhaust
  if (clicks > 1) {
    console.log('\nPlay second ad to exhaust campaign:');
    const next2 = await req('GET', '/api/ads/next');
    check('Second ad available', next2.json?.hasAd === true);
    const play2 = await req('POST', '/api/ads/play', { campaignId }, {});
    check('Second play returns 200', play2.status === 200, `got ${play2.status}`);

    // Check campaign is now completed
    const camps2 = await req('GET', '/api/ads/campaigns', undefined, authHeader);
    const camp2 = camps2.json?.campaigns?.[0];
    check('Campaign status = completed', camp2?.status === 'completed', `got ${camp2?.status}`);
    check('Campaign clicks_served = clicks', camp2?.clicks_served === clicks);

    // 10. Check has-ads = false
    const has2 = await req('GET', '/api/ads/has-ads');
    check('has-ads = false after campaign exhausted', has2.json?.hasAds === false, `got ${has2.json?.hasAds}`);
  } else {
    // Single-click campaign should also be completed
    const camps2 = await req('GET', '/api/ads/campaigns', undefined, authHeader);
    check('Single-click campaign completed', camps2.json?.campaigns?.[0]?.status === 'completed');
    const has2 = await req('GET', '/api/ads/has-ads');
    check('has-ads = false after single-click exhausted', has2.json?.hasAds === false);
  }

  // 11. Try to play ad when none available
  console.log('\nNo ads available:');
  const nextNone = await req('GET', '/api/ads/next');
  check('next returns hasAd=false', nextNone.json?.hasAd === false);

  // 12. Try to create campaign with insufficient tokens
  console.log('\nInsufficient tokens test:');
  const meFinal = await req('GET', '/api/me', undefined, authHeader);
  const finalBalance = meFinal.json?.tokens || 0;
  console.log(`  Final balance: ${finalBalance}`);
  const broke = await req('POST', '/api/ads/campaign', {
    gameId: 'test', gameTitle: 'test', clicks: 1000,
  }, authHeader);
  check('Insufficient tokens returns 402', broke.status === 402, `got ${broke.status}`);

  console.log(`\n${'='.repeat(60)}`);
  console.log(`  ${pass} passed, ${fail} failed`);
  console.log(`${'='.repeat(60)}\n`);
  process.exit(fail > 0 ? 1 : 0);
}

main().catch(e => {
  console.error('Test crashed:', e);
  process.exit(1);
});
