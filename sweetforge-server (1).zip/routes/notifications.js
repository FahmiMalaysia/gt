/**
 * routes/notifications.js — Inbox / notification system
 *
 * Endpoints:
 *   GET  /api/me/notifications          — list (max 50, newest first)
 *   GET  /api/me/notifications/unread    — count unread
 *   POST /api/me/notifications/:id/read  — mark one as read
 *   POST /api/me/notifications/read-all  — mark all as read
 *   DELETE /api/me/notifications/:id     — delete one
 */

const express = require('express');
const { stmts } = require('../lib/db');
const { authOptional } = require('../middleware/auth');
const { getOrCreateIpUser } = require('../lib/ipUser');

const router = express.Router();

function resolveUser(req, res) {
  if (req.user?.id) {
    const u = stmts.findById.get(req.user.id);
    if (u) return u;
  }
  if (process.env.DISABLE_ANONYMOUS === 'true') {
    res.status(401).json({ error: 'Authentication required' });
    return null;
  }
  return getOrCreateIpUser(req);
}

// GET /api/me/notifications
router.get('/', authOptional, (req, res) => {
  const user = resolveUser(req, res);
  if (!user) return;

  const notifications = stmts.listNotifications.all(user.id);
  res.json({ notifications });
});

// GET /api/me/notifications/unread
router.get('/unread', authOptional, (req, res) => {
  const user = resolveUser(req, res);
  if (!user) return;

  const r = stmts.countUnreadNotifications.get(user.id);
  res.json({ unread: r?.n || 0 });
});

// POST /api/me/notifications/:id/read
router.post('/:id/read', authOptional, (req, res) => {
  const user = resolveUser(req, res);
  if (!user) return;

  const { id } = req.params;
  stmts.markNotificationRead.run(id, user.id);
  res.json({ read: true });
});

// POST /api/me/notifications/read-all
router.post('/read-all', authOptional, (req, res) => {
  const user = resolveUser(req, res);
  if (!user) return;

  stmts.markAllNotificationsRead.run(user.id);
  res.json({ readAll: true });
});

// DELETE /api/me/notifications/:id
router.delete('/:id', authOptional, (req, res) => {
  const user = resolveUser(req, res);
  if (!user) return;

  const { id } = req.params;
  stmts.deleteNotification.run(id, user.id);
  res.json({ deleted: true });
});

module.exports = router;
