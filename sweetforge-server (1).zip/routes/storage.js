/**
 * routes/storage.js — Object storage REST API
 *
 * COMPATIBLE dengan publishStorage.ts (APK client):
 *   POST   /v1/users                              register storage user (auto)
 *   PUT    /v1/users/<uid>/objects/<key>          upload binary
 *   GET    /v1/users/<uid>/objects/<key>          download binary
 *   GET    /v1/users/<uid>/objects?prefix=<p>     list objects
 *   DELETE /v1/users/<uid>/objects/<key>          delete object
 *
 * AUTH: Setiap request kena ada JWT (Authorization: Bearer <token>).
 *       User hanya boleh akses storage sendiri (req.user.id).
 *
 * EXCEPTION: Untuk backward-compat dengan APK lama yang belum update,
 *            kalau takde JWT, guna "default-user" (auto-create).
 *            Boleh dimatikan dengan env DISABLE_ANONYMOUS=true.
 */

const express = require('express');
const crypto = require('crypto');
const { raw } = require('body-parser');
const { stmts } = require('../lib/db');
const { authOptional, authRequired } = require('../middleware/auth');
const { putObject, getObject, deleteObject, listObjects } = require('../lib/objects');
const { uploadLimiter } = require('../middleware/rateLimit');
const { getOrCreateIpUser, USER_QUOTA } = require('../lib/ipUser');

const router = express.Router();

const MAX_UPLOAD = parseInt(process.env.MAX_UPLOAD_BYTES || '5242880', 10); // 5MB

/**
 * Resolve user ID from JWT or fallback to IP-based anonymous user.
 * When DISABLE_ANONYMOUS=true, requests without JWT will get 401.
 */
function resolveUserId(req, res) {
  if (req.user?.id) return req.user.id;
  if (process.env.DISABLE_ANONYMOUS === 'true') {
    res.status(401).json({ error: 'Authentication required' });
    return null;
  }
  // 1 IP = 1 user. Auto-create anonymous user from IP.
  const user = getOrCreateIpUser(req);
  return user.id;
}

/**
 * Ensure user exists in DB (for explicitly-named user IDs).
 */
function ensureUserExists(userId) {
  let user = stmts.findById.get(userId);
  if (!user) {
    stmts.insertUser.run({
      id: userId,
      email: `${userId}@local`,
      username: userId,
      password_hash: '!',
      display_name: userId,
      storage_quota: USER_QUOTA,
      is_anonymous: 1,
      source_ip: null,
    });
    user = stmts.findById.get(userId);
  }
  return user;
}

// ---------------------------------------------------------------------------
// POST /v1/users — register storage user (auto-create bila ensureUser)
// ---------------------------------------------------------------------------
router.post('/users', authOptional, (req, res, next) => {
  try {
    const userId = resolveUserId(req, res);
    if (!userId) return;

    const { userId: bodyUserId, quotaBytes } = req.body || {};
    const finalUserId = bodyUserId || userId;

    if (!/^[a-zA-Z0-9_-]+$/.test(finalUserId)) {
      return res.status(400).json({ error: 'Invalid userId' });
    }

    let user = stmts.findById.get(finalUserId);
    if (user) {
      return res.status(409).json({ error: 'User already exists', userId: finalUserId });
    }

    stmts.insertUser.run({
      id: finalUserId,
      email: `${finalUserId}@local`,
      username: finalUserId,
      password_hash: '!',
      display_name: finalUserId,
      storage_quota: quotaBytes || USER_QUOTA,
    });

    res.status(201).json({ userId: finalUserId, quotaBytes: quotaBytes || USER_QUOTA });
  } catch (e) {
    next(e);
  }
});

// ---------------------------------------------------------------------------
// PUT /v1/users/:userId/objects/* — upload binary
// ---------------------------------------------------------------------------
router.put('/users/:userId/objects/*', authOptional, uploadLimiter, raw({ type: '*/*', limit: MAX_UPLOAD }), (req, res, next) => {
  (async () => {
    try {
      const requestUserId = resolveUserId(req, res);
      if (!requestUserId) return;

      const targetUserId = req.params.userId;
      // SECURITY: user hanya boleh upload ke storage sendiri
      if (targetUserId !== requestUserId) {
        return res.status(403).json({ error: 'Cannot write to another user storage' });
      }

      const user = ensureUserExists(targetUserId);
      const key = req.params[0]; // wildcard after /objects/
      if (!key) return res.status(400).json({ error: 'Missing object key' });

      const buffer = req.body;
      if (!Buffer.isBuffer(buffer)) {
        return res.status(400).json({ error: 'Body must be raw bytes' });
      }

      // Quota check
      const usedRow = stmts.sumObjectSizes.get(targetUserId);
      const currentUsed = usedRow?.total || 0;
      const existing = stmts.findObject.get(targetUserId, key);
      const existingSize = existing?.size_bytes || 0;
      const newTotal = currentUsed - existingSize + buffer.length;
      if (newTotal > user.storage_quota) {
        return res.status(413).json({
          error: 'Quota exceeded',
          quota: user.storage_quota,
          used: currentUsed,
          needed: newTotal,
        });
      }

      const contentType = req.headers['content-type'] || 'application/octet-stream';
      await putObject(targetUserId, key, buffer, contentType);

      stmts.insertObject.run({
        id: crypto.randomUUID(),
        user_id: targetUserId,
        key,
        size_bytes: buffer.length,
        content_type: contentType,
      });

      // Update user storage_used
      stmts.updateStorageUsed.run(newTotal, targetUserId);

      res.status(200).json({
        key,
        sizeBytes: buffer.length,
        contentType,
      });
    } catch (e) {
      next(e);
    }
  })();
});

// ---------------------------------------------------------------------------
// GET /v1/users/:userId/objects?prefix=  — list objects (no trailing path)
// ---------------------------------------------------------------------------
router.get('/users/:userId/objects', authOptional, (req, res, next) => {
  (async () => {
    try {
      const requestUserId = resolveUserId(req, res);
      if (!requestUserId) return;

      const targetUserId = req.params.userId;
      if (targetUserId !== requestUserId) {
        return res.status(403).json({ error: 'Cannot read another user storage' });
      }

      ensureUserExists(targetUserId);

      const prefix = String(req.query.prefix || '');
      const items = await listObjects(targetUserId, prefix);
      return res.json({ items, objects: items, count: items.length });
    } catch (e) {
      next(e);
    }
  })();
});

// ---------------------------------------------------------------------------
// GET /v1/users/:userId/objects/*  — download single object
// ---------------------------------------------------------------------------
router.get('/users/:userId/objects/*', authOptional, (req, res, next) => {
  (async () => {
    try {
      const requestUserId = resolveUserId(req, res);
      if (!requestUserId) return;

      const targetUserId = req.params.userId;
      if (targetUserId !== requestUserId) {
        return res.status(403).json({ error: 'Cannot read another user storage' });
      }

      ensureUserExists(targetUserId);

      // Otherwise download single object
      const key = req.params[0];
      if (!key) return res.status(400).json({ error: 'Missing object key' });

      const buffer = await getObject(targetUserId, key);
      if (!buffer) return res.status(404).json({ error: 'Object not found' });

      const obj = stmts.findObject.get(targetUserId, key);
      res.setHeader('Content-Type', obj?.content_type || 'application/octet-stream');
      res.setHeader('Content-Length', buffer.length);
      res.setHeader('Cache-Control', 'public, max-age=300');
      return res.send(buffer);
    } catch (e) {
      next(e);
    }
  })();
});

// ---------------------------------------------------------------------------
// DELETE /v1/users/:userId/objects/*
// ---------------------------------------------------------------------------
router.delete('/users/:userId/objects/*', authOptional, (req, res, next) => {
  (async () => {
    try {
      const requestUserId = resolveUserId(req, res);
      if (!requestUserId) return;

      const targetUserId = req.params.userId;
      if (targetUserId !== requestUserId) {
        return res.status(403).json({ error: 'Cannot delete from another user storage' });
      }

      const key = req.params[0];
      if (!key) return res.status(400).json({ error: 'Missing object key' });

      const existing = stmts.findObject.get(targetUserId, key);
      if (!existing) return res.status(404).json({ error: 'Object not found' });

      await deleteObject(targetUserId, key);
      stmts.deleteObject.run(targetUserId, key);

      // Recompute user storage_used
      const usedRow = stmts.sumObjectSizes.get(targetUserId);
      stmts.updateStorageUsed.run(usedRow?.total || 0, targetUserId);

      res.json({ deleted: true, key });
    } catch (e) {
      next(e);
    }
  })();
});

module.exports = router;
