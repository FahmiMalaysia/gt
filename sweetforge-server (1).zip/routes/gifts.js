/**
 * routes/gifts.js — Gift / Progress / Token system
 *
 * Endpoints (all require auth OR anonymous IP-based user):
 *   GET  /api/me                  — current user state (id, storage, tokens)
 *   GET  /api/me/progress         — list of all progress + claimable status
 *   GET  /api/me/gift-status      — { hasClaimable: bool } (lightweight polling)
 *   POST /api/me/progress/track   — track an event { eventType, refId? }
 *   POST /api/me/progress/claim   — claim a reward { rewardId }
 *   GET  /api/me/tokens           — token balance + recent transactions
 *
 * The "gift" system:
 *   - Server computes which rewards are claimable.
 *   - Client caches `hasClaimable` in localStorage.
 *   - When user clicks claim button, server verifies + awards tokens.
 */

const express = require('express');
const crypto = require('crypto');
const { stmts, db } = require('../lib/db');
const { authOptional } = require('../middleware/auth');
const { getOrCreateIpUser } = require('../lib/ipUser');
const { REWARDS, computeProgress, hasClaimableGifts } = require('../lib/progress');

const router = express.Router();

const VALID_EVENT_TYPES = new Set(['publish', 'play', 'install', 'comment', 'vote', 'login']);

function resolveUser(req, res) {
  if (req.user?.id) {
    const u = stmts.findById.get(req.user.id);
    if (u) return u;
  }
  if (process.env.DISABLE_ANONYMOUS === 'true') {
    res.status(401).json({ error: 'Authentication required' });
    return null;
  }
  return getOrCreateIpUser(req);
}

// ---------------------------------------------------------------------------
// GET /api/me — current user state (lightweight)
// ---------------------------------------------------------------------------
router.get('/me', authOptional, (req, res) => {
  const user = resolveUser(req, res);
  if (!user) return;

  const balRow = stmts.getTokenBalance.get(user.id);
  const tokens = balRow?.balance || 0;

  res.json({
    user: {
      id: user.id,
      username: user.username,
      displayName: user.display_name,
      isAnonymous: !!user.is_anonymous,
      email: user.is_anonymous ? null : user.email,
      createdAt: user.created_at,
      lastLoginAt: user.last_login_at,
    },
    storage: {
      quota: user.storage_quota,
      used: user.storage_used,
      free: Math.max(0, user.storage_quota - user.storage_used),
    },
    tokens,
  });
});

// ---------------------------------------------------------------------------
// GET /api/me/progress — all progress + claimable status
// ---------------------------------------------------------------------------
router.get('/me/progress', authOptional, (req, res) => {
  const user = resolveUser(req, res);
  if (!user) return;

  const progress = computeProgress(stmts, user.id);
  const claimableCount = progress.filter((p) => p.claimable).length;

  res.json({
    progress,
    claimableCount,
    hasClaimable: claimableCount > 0,
  });
});

// ---------------------------------------------------------------------------
// GET /api/me/gift-status — lightweight polling for red dot indicator
// ---------------------------------------------------------------------------
router.get('/me/gift-status', authOptional, (req, res) => {
  const user = resolveUser(req, res);
  if (!user) return;

  const hasGifts = hasClaimableGifts(stmts, user.id);
  res.json({
    hasClaimable: hasGifts,
    timestamp: Date.now(),
  });
});

// ---------------------------------------------------------------------------
// POST /api/me/progress/track — record an event
// Body: { eventType: "publish"|"play"|"install"|"comment"|"vote"|"login", refId?: string }
// ---------------------------------------------------------------------------
router.post('/me/progress/track', authOptional, (req, res) => {
  const user = resolveUser(req, res);
  if (!user) return;

  const { eventType, refId } = req.body || {};
  if (!eventType || !VALID_EVENT_TYPES.has(eventType)) {
    return res.status(400).json({
      error: 'Invalid eventType. Valid: ' + Array.from(VALID_EVENT_TYPES).join(', '),
    });
  }

  // For refId-tracked events, dedupe: don't insert if same (user, eventType, refId) exists
  if (refId) {
    const existing = stmts.countProgressEventsWithRef.get(user.id, eventType, refId);
    if (existing?.n > 0) {
      // Already tracked — return current state without inserting
      const progress = computeProgress(stmts, user.id);
      return res.json({
        tracked: false,
        reason: 'duplicate',
        progress,
      });
    }
  }

  stmts.addProgressEvent.run({
    id: crypto.randomUUID(),
    user_id: user.id,
    event_type: eventType,
    ref_id: refId || null,
  });

  const progress = computeProgress(stmts, user.id);
  res.json({
    tracked: true,
    progress,
  });
});

// ---------------------------------------------------------------------------
// POST /api/me/progress/claim — claim a reward
// Body: { rewardId: string }
// Returns: { claimed: bool, tokensAwarded: int, newBalance: int }
// ---------------------------------------------------------------------------
router.post('/me/progress/claim', authOptional, (req, res) => {
  const user = resolveUser(req, res);
  if (!user) return;

  const { rewardId } = req.body || {};
  if (!rewardId) {
    return res.status(400).json({ error: 'Missing rewardId' });
  }

  const reward = REWARDS.find((r) => r.id === rewardId);
  if (!reward) {
    return res.status(404).json({ error: 'Unknown reward' });
  }

  // Check if already claimed
  if (stmts.isClaimed.get(user.id, rewardId)) {
    return res.status(409).json({ error: 'Already claimed' });
  }

  // Check if progress is complete
  const progress = computeProgress(stmts, user.id);
  const p = progress.find((x) => x.id === rewardId);
  if (!p || !p.completed) {
    return res.status(403).json({
      error: 'Requirement not met',
      current: p?.current || 0,
      target: reward.target,
    });
  }

  // Atomic: claim + award tokens in a transaction
  const tx = db.transaction(() => {
    stmts.claimReward.run({
      id: crypto.randomUUID(),
      user_id: user.id,
      reward_id: rewardId,
      tokens_awarded: reward.tokens,
    });

    const balRow = stmts.getTokenBalance.get(user.id);
    const currentBalance = balRow?.balance || 0;
    const newBalance = currentBalance + reward.tokens;
    stmts.upsertTokenBalance.run({
      user_id: user.id,
      balance: newBalance,
    });

    stmts.addTokenTx.run({
      id: crypto.randomUUID(),
      user_id: user.id,
      delta: reward.tokens,
      reason: `reward:${rewardId}`,
      ref_id: null,
    });

    return newBalance;
  });

  try {
    const newBalance = tx();
    res.json({
      claimed: true,
      rewardId,
      tokensAwarded: reward.tokens,
      newBalance,
    });
  } catch (e) {
    if (e.code === 'SQLITE_CONSTRAINT_UNIQUE') {
      return res.status(409).json({ error: 'Already claimed' });
    }
    throw e;
  }
});

// ---------------------------------------------------------------------------
// GET /api/me/tokens — token balance + recent transactions
// ---------------------------------------------------------------------------
router.get('/me/tokens', authOptional, (req, res) => {
  const user = resolveUser(req, res);
  if (!user) return;

  const balRow = stmts.getTokenBalance.get(user.id);
  const balance = balRow?.balance || 0;

  const recentTx = db.prepare(`
    SELECT * FROM token_transactions
    WHERE user_id = ?
    ORDER BY created_at DESC
    LIMIT 20
  `).all(user.id);

  res.json({
    balance,
    recentTransactions: recentTx,
  });
});

module.exports = router;
