/**
 * routes/games.js — Public game listing (untuk Explorer storefront)
 *
 * Baca semua *.meta.json dari SEMUA user storage, gabungkan, sort by publishedAt.
 * Endpoint ni TAK perlu auth — untuk paparan umum di Explorer.
 */

const express = require('express');
const fs = require('fs');
const path = require('path');
const { promises: fsp } = require('fs');
const { authOptional } = require('../middleware/auth');

const router = express.Router();

const STORAGE_ROOT = path.join(__dirname, '..', 'data', 'storage');

/**
 * GET /api/games — list semua published games (metadata only)
 * GET /api/games/:userId/:gameId/download — download zip
 */
router.get('/games', async (req, res, next) => {
  try {
    if (!fs.existsSync(STORAGE_ROOT)) {
      return res.json({ games: [], count: 0 });
    }

    const games = [];
    const userDirs = await fsp.readdir(STORAGE_ROOT, { withFileTypes: true });

    for (const userDir of userDirs) {
      if (!userDir.isDirectory()) continue;
      const gamesFolder = path.join(STORAGE_ROOT, userDir.name, 'games');
      if (!fs.existsSync(gamesFolder)) continue;

      const files = await fsp.readdir(gamesFolder);
      for (const file of files) {
        if (!file.endsWith('.meta.json')) continue;
        try {
          const raw = await fsp.readFile(path.join(gamesFolder, file), 'utf8');
          const meta = JSON.parse(raw);
          meta.ownerUserId = userDir.name;
          games.push(meta);
        } catch (e) {
          console.warn('Failed to read meta', file, e.message);
        }
      }
    }

    games.sort((a, b) => (b.publishedAt || 0) - (a.publishedAt || 0));
    res.json({ games, count: games.length });
  } catch (e) {
    next(e);
  }
});

/**
 * GET /api/games/:userId/:gameId/download — download zip game
 */
router.get('/games/:userId/:gameId/download', async (req, res, next) => {
  try {
    const { userId, gameId } = req.params;
    if (!/^[a-zA-Z0-9_-]+$/.test(userId) || !/^[a-zA-Z0-9_-]+$/.test(gameId)) {
      return res.status(400).json({ error: 'Invalid id' });
    }

    const zipPath = path.join(STORAGE_ROOT, userId, 'games', `${gameId}.aegame.zip`);
    if (!fs.existsSync(zipPath)) {
      return res.status(404).json({ error: 'Game not found' });
    }

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${gameId}.aegame.zip"`);
    const stream = fs.createReadStream(zipPath);
    stream.on('error', next);
    stream.pipe(res);
  } catch (e) {
    next(e);
  }
});

module.exports = router;
