/**
 * routes/auth.js — Authentication routes (signup, login, me, captcha)
 *
 * POST /auth/captcha/challenge  — get a PoW challenge (no rate limit beyond general)
 * POST /auth/signup             — register (requires solved captcha)
 * POST /auth/login              — login (no captcha needed, password is enough)
 * GET  /auth/me                 — current user info (perlu token)
 */

const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { stmts } = require('../lib/db');
const { signToken, authRequired } = require('../middleware/auth');
const { loginLimiter, signupLimiter } = require('../middleware/rateLimit');
const { issueChallenge, verifyChallenge } = require('../lib/captcha');
const { getOrCreateIpUser } = require('../lib/ipUser');

const router = express.Router();

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const USERNAME_RE = /^[a-zA-Z0-9_]{3,30}$/;
const PASSWORD_MIN = 8;

// ---------------------------------------------------------------------------
// POST /auth/captcha/challenge — issue a PoW challenge
// ---------------------------------------------------------------------------
router.post('/captcha/challenge', (req, res) => {
  const c = issueChallenge();
  res.json(c);
});

// ---------------------------------------------------------------------------
// POST /auth/signup — register akaun baru (requires solved PoW captcha)
// ---------------------------------------------------------------------------
router.post('/signup', signupLimiter, (req, res, next) => {
  try {
    const { email, username, password, displayName, challenge, nonce } = req.body || {};

    if (!email || !username || !password) {
      return res.status(400).json({
        error: 'Missing required fields: email, username, password',
      });
    }
    if (!EMAIL_RE.test(email)) {
      return res.status(400).json({ error: 'Invalid email format' });
    }
    if (!USERNAME_RE.test(username)) {
      return res.status(400).json({
        error: 'Username must be 3-30 chars, alphanumeric + underscore only',
      });
    }
    if (password.length < PASSWORD_MIN) {
      return res.status(400).json({
        error: `Password must be at least ${PASSWORD_MIN} characters`,
      });
    }

    // Verify captcha (PoW challenge)
    if (!challenge || nonce === undefined || nonce === null) {
      return res.status(400).json({
        error: 'Captcha required. GET /auth/captcha/challenge first, then solve it.',
      });
    }
    if (!verifyChallenge(challenge, nonce)) {
      return res.status(403).json({
        error: 'Captcha verification failed. Get a new challenge and try again.',
      });
    }

    // Check duplicates
    if (stmts.findByEmail.get(email.toLowerCase())) {
      return res.status(409).json({ error: 'Email already registered' });
    }
    if (stmts.findByUsername.get(username.toLowerCase())) {
      return res.status(409).json({ error: 'Username already taken' });
    }

    const id = `u_${crypto.randomBytes(12).toString('hex')}`;
    const passwordHash = bcrypt.hashSync(password, 10);
    const quota = parseInt(process.env.USER_QUOTA_BYTES || '10485760', 10);

    stmts.insertUser.run({
      id,
      email: email.toLowerCase(),
      username: username.toLowerCase(),
      password_hash: passwordHash,
      display_name: displayName || username,
      storage_quota: quota,
      is_anonymous: 0,
      source_ip: null,
    });

    // Track login event for daily reward
    stmts.addProgressEvent.run({
      id: crypto.randomUUID(),
      user_id: id,
      event_type: 'login',
      ref_id: `signup_${id}`,
    });

    const token = signToken({ id, email, username });

    res.status(201).json({
      message: 'Account created',
      user: {
        id,
        email: email.toLowerCase(),
        username: username.toLowerCase(),
        displayName: displayName || username,
      },
      token,
    });
  } catch (e) {
    next(e);
  }
});

// ---------------------------------------------------------------------------
// POST /auth/login — login dengan password (no captcha)
// ---------------------------------------------------------------------------
router.post('/login', loginLimiter, (req, res, next) => {
  try {
    const { email, username, password } = req.body || {};

    if (!password || (!email && !username)) {
      return res.status(400).json({
        error: 'Provide either email or username, plus password',
      });
    }

    let user;
    if (email) {
      user = stmts.findByEmail.get(email.toLowerCase());
    } else {
      user = stmts.findByUsername.get(username.toLowerCase());
    }

    if (!user || !bcrypt.compareSync(password, user.password_hash)) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    stmts.updateLastLogin.run(user.id);

    // Track login event for daily reward (dedup by refId = today's date)
    const today = new Date().toISOString().slice(0, 10);
    const existing = stmts.countProgressEventsWithRef.get(user.id, 'login', `daily_${today}`);
    if (!existing?.n) {
      stmts.addProgressEvent.run({
        id: crypto.randomUUID(),
        user_id: user.id,
        event_type: 'login',
        ref_id: `daily_${today}`,
      });
    }

    const token = signToken(user);

    res.json({
      message: 'Login successful',
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        displayName: user.display_name,
      },
      token,
    });
  } catch (e) {
    next(e);
  }
});

// ---------------------------------------------------------------------------
// GET /auth/me — current user info
// ---------------------------------------------------------------------------
router.get('/me', authRequired, (req, res) => {
  const user = stmts.findById.get(req.user.id);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  const balRow = stmts.getTokenBalance.get(user.id);
  const tokens = balRow?.balance || 0;

  res.json({
    user: {
      id: user.id,
      email: user.email,
      username: user.username,
      displayName: user.display_name,
      isAnonymous: !!user.is_anonymous,
      storageQuota: user.storage_quota,
      storageUsed: user.storage_used,
      tokens,
      createdAt: user.created_at,
      lastLoginAt: user.last_login_at,
    },
  });
});

module.exports = router;
