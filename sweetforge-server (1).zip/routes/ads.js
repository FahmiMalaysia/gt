/**
 * routes/ads.js — Ads system for SweetForge
 *
 * Endpoints:
 *   POST /api/ads/campaign          — developer creates ad campaign (pays tokens)
 *   GET  /api/ads/campaigns         — list developer's own campaigns
 *   GET  /api/ads/next              — player gets next ad to show (returns game info)
 *   POST /api/ads/play              — player reports ad was shown (awards dev 2 tokens)
 *   GET  /api/ads/has-ads           — check if any ads available (for iklan_has_isi)
 *   GET  /api/ads/has-ads/:gameId   — check if ads available for specific game
 *   GET  /api/ads/pending-tokens    — developer's pending tokens (last 1 min)
 *
 * Token economics:
 *   - Developer pays: clicks * 4 tokens per click (e.g. 2 clicks = 8 tokens)
 *   - Per ad play: developer EARNS 2 tokens (incentive to make good games)
 *   - Server fee: 4 - 2 = 2 tokens per click (covers platform cost)
 *   - Net cost to developer: (4 - 2) * clicks = 2 * clicks
 *   - So 8 tokens buys 2 clicks, dev earns back 4 (2 per click), net cost = 4 tokens
 *
 * Ad content: code-based (HTML/CSS), shown for 5 seconds. No video.
 */

const express = require('express');
const crypto = require('crypto');
const { stmts, db } = require('../lib/db');
const { authOptional } = require('../middleware/auth');
const { getOrCreateIpUser } = require('../lib/ipUser');

const router = express.Router();

const TOKENS_PER_CLICK_COST = 4;   // dev pays 4 tokens per click
const TOKENS_PER_AD_PLAY = 2;      // dev earns 2 tokens per ad play

function resolveUser(req, res) {
  if (req.user?.id) {
    const u = stmts.findById.get(req.user.id);
    if (u) return u;
  }
  if (process.env.DISABLE_ANONYMOUS === 'true') {
    res.status(401).json({ error: 'Authentication required' });
    return null;
  }
  return getOrCreateIpUser(req);
}

// ---------------------------------------------------------------------------
// POST /api/ads/campaign — create ad campaign
// Body: { gameId, gameTitle, clicks }
// ---------------------------------------------------------------------------
router.post('/campaign', authOptional, (req, res) => {
  const user = resolveUser(req, res);
  if (!user) return;

  const { gameId, gameTitle, clicks } = req.body || {};
  if (!gameId || !gameTitle || !clicks) {
    return res.status(400).json({ error: 'Missing gameId, gameTitle, or clicks' });
  }
  const clickCount = parseInt(clicks, 10);
  if (isNaN(clickCount) || clickCount < 1 || clickCount > 1000) {
    return res.status(400).json({ error: 'clicks must be 1-1000' });
  }

  const totalCost = clickCount * TOKENS_PER_CLICK_COST;

  // Check balance
  const balRow = stmts.getTokenBalance.get(user.id);
  const balance = balRow?.balance || 0;
  if (balance < totalCost) {
    return res.status(402).json({
      error: 'Insufficient tokens',
      needed: totalCost,
      balance,
    });
  }

  // Atomic: deduct tokens + create campaign
  const campaignId = crypto.randomUUID();
  const tx = db.transaction(() => {
    // Deduct tokens
    stmts.upsertTokenBalance.run({
      user_id: user.id,
      balance: balance - totalCost,
    });
    stmts.addTokenTx.run({
      id: crypto.randomUUID(),
      user_id: user.id,
      delta: -totalCost,
      reason: `ad_campaign:${campaignId}`,
      ref_id: gameId,
    });

    // Create campaign
    stmts.insertAdCampaign.run({
      id: campaignId,
      developer_id: user.id,
      game_id: gameId,
      game_title: gameTitle,
      clicks_purchased: clickCount,
      tokens_paid: totalCost,
    });
  });

  try {
    tx();
    res.status(201).json({
      campaignId,
      gameId,
      gameTitle,
      clicksPurchased: clickCount,
      tokensPaid: totalCost,
      newBalance: balance - totalCost,
    });
  } catch (e) {
    res.status(500).json({ error: 'Failed to create campaign' });
  }
});

// ---------------------------------------------------------------------------
// GET /api/ads/campaigns — list developer's own campaigns
// ---------------------------------------------------------------------------
router.get('/campaigns', authOptional, (req, res) => {
  const user = resolveUser(req, res);
  if (!user) return;

  const campaigns = stmts.listMyAdCampaigns.all(user.id);
  res.json({ campaigns });
});

// ---------------------------------------------------------------------------
// GET /api/ads/next — player gets next ad to show
// Returns: { hasAd, campaign?: { campaignId, gameId, gameTitle, adContent } }
// ---------------------------------------------------------------------------
router.get('/next', authOptional, (req, res) => {
  const user = resolveUser(req, res);
  if (!user) return;

  const campaign = stmts.pickNextAdCampaign.get();
  if (!campaign) {
    return res.json({ hasAd: false });
  }

  // Generate code-based ad content (HTML/CSS as string)
  // In production, this would be a curated ad template.
  const adContent = generateAdContent(campaign);

  res.json({
    hasAd: true,
    campaign: {
      campaignId: campaign.id,
      gameId: campaign.game_id,
      gameTitle: campaign.game_title,
      adContent,
      durationSec: 5,
    },
  });
});

// ---------------------------------------------------------------------------
// POST /api/ads/play — player reports ad was shown
// Body: { campaignId }
// Awards developer 2 tokens, increments campaign clicks_served.
// ---------------------------------------------------------------------------
router.post('/play', authOptional, (req, res) => {
  const user = resolveUser(req, res);
  if (!user) return;

  const { campaignId } = req.body || {};
  if (!campaignId) {
    return res.status(400).json({ error: 'Missing campaignId' });
  }

  const campaign = stmts.getAdCampaign.get(campaignId);
  if (!campaign) {
    return res.status(404).json({ error: 'Campaign not found' });
  }
  if (campaign.status !== 'active' || campaign.clicks_served >= campaign.clicks_purchased) {
    return res.status(410).json({ error: 'Campaign exhausted or completed' });
  }

  // Atomic: increment served + award dev tokens + log ad play + send notification
  const tx = db.transaction(() => {
    // Increment campaign
    stmts.incrementAdServed.run(campaign.id);

    // Award developer 2 tokens
    const devBalRow = stmts.getTokenBalance.get(campaign.developer_id);
    const devBalance = (devBalRow?.balance || 0) + TOKENS_PER_AD_PLAY;
    stmts.upsertTokenBalance.run({
      user_id: campaign.developer_id,
      balance: devBalance,
    });
    stmts.addTokenTx.run({
      id: crypto.randomUUID(),
      user_id: campaign.developer_id,
      delta: TOKENS_PER_AD_PLAY,
      reason: `ad_play:${campaign.id}`,
      ref_id: campaign.game_id,
    });

    // Log ad play
    stmts.insertAdPlay.run({
      id: crypto.randomUUID(),
      campaign_id: campaign.id,
      player_id: user.id,
      developer_id: campaign.developer_id,
      tokens_earned: TOKENS_PER_AD_PLAY,
    });

    // Send notification to developer: "Your ad for game X was played"
    stmts.insertNotification.run({
      id: crypto.randomUUID(),
      user_id: campaign.developer_id,
      type: 'ad_play',
      title: 'Ad Played',
      message: `A player played your ad for "${campaign.game_title}". +${TOKENS_PER_AD_PLAY}T pending.`,
      ref_id: campaign.game_id,
    });

    // Check if campaign just completed — send completion notification
    const updated = stmts.getAdCampaign.get(campaign.id);
    if (updated && updated.status === 'completed') {
      stmts.insertNotification.run({
        id: crypto.randomUUID(),
        user_id: campaign.developer_id,
        type: 'campaign_completed',
        title: 'Campaign Completed',
        message: `Your ad campaign for "${campaign.game_title}" has completed. ${updated.clicks_served}/${updated.clicks_purchased} clicks served.`,
        ref_id: campaign.id,
      });
    }
  });

  try {
    tx();
    res.json({
      played: true,
      campaignId: campaign.id,
      developerEarned: TOKENS_PER_AD_PLAY,
    });
  } catch (e) {
    res.status(500).json({ error: 'Failed to record ad play' });
  }
});

// ---------------------------------------------------------------------------
// GET /api/ads/has-ads — check if any ads available (global)
// Used by script engine: iklan_has_isi
// ---------------------------------------------------------------------------
router.get('/has-ads', authOptional, (req, res) => {
  resolveUser(req, res); // ensure user exists (not strictly needed)
  const r = stmts.countActiveCampaigns.get();
  res.json({ hasAds: (r?.n || 0) > 0, count: r?.n || 0 });
});

// ---------------------------------------------------------------------------
// GET /api/ads/has-ads/:gameId — check if ads available for specific game
// ---------------------------------------------------------------------------
router.get('/has-ads/:gameId', authOptional, (req, res) => {
  resolveUser(req, res);
  const { gameId } = req.params;
  if (!gameId) return res.status(400).json({ error: 'Missing gameId' });
  const r = stmts.countActiveCampaignsForGame.get(gameId);
  res.json({ hasAds: (r?.n || 0) > 0, count: r?.n || 0, gameId });
});

// ---------------------------------------------------------------------------
// GET /api/ads/pending-tokens — developer's pending tokens (last 1 min)
// ---------------------------------------------------------------------------
router.get('/pending-tokens', authOptional, (req, res) => {
  const user = resolveUser(req, res);
  if (!user) return;

  const r = stmts.sumPendingAdTokens.get(user.id);
  const pending = r?.total || 0;

  // Also get total ad plays all-time
  const playsRow = stmts.countAdPlays.get(user.id);
  const totalPlays = playsRow?.n || 0;

  res.json({
    pendingTokens: pending,
    windowSec: 60,
    totalAdPlays: totalPlays,
  });
});

// ---------------------------------------------------------------------------
// Helper: generate code-based ad content (HTML/CSS string)
// ---------------------------------------------------------------------------
function generateAdContent(campaign) {
  // Code-based ad — no video. 5-second display.
  // Returns HTML string that the client renders in an iframe/div.
  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  body { margin:0; padding:0; font-family:system-ui,sans-serif; background:#0a0a0a; color:#fff; display:flex; align-items:center; justify-content:center; min-height:100vh; overflow:hidden; }
  .ad { text-align:center; padding:20px; max-width:400px; }
  .badge { display:inline-block; background:#f5a623; color:#000; font-size:9px; font-weight:900; padding:2px 8px; border-radius:2px; letter-spacing:1px; margin-bottom:12px; text-transform:uppercase; }
  .title { font-size:20px; font-weight:800; margin:0 0 8px; color:#fff; }
  .sub { font-size:12px; color:#888; margin:0 0 16px; }
  .play-btn { display:inline-block; background:#4a90e2; color:#fff; padding:10px 24px; border-radius:4px; font-size:12px; font-weight:700; text-decoration:none; }
  .footer { position:fixed; bottom:8px; right:8px; font-size:9px; color:#444; }
</style>
</head>
<body>
  <div class="ad">
    <span class="badge">Ad</span>
    <h1 class="title">${escapeHtml(campaign.game_title)}</h1>
    <p class="sub">Try this game on SweetForge</p>
    <a href="#" class="play-btn">Play Now</a>
  </div>
  <div class="footer">SweetForge Ads · 5s</div>
</body>
</html>`;
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

module.exports = router;
