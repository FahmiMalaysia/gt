/**
 * middleware/errorHandler.js — Centralized error handling
 */

function notFound(req, res) {
  res.status(404).json({ error: 'Not found', path: req.path });
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  console.error(`[ERROR] ${req.method} ${req.path}:`, err.message);

  if (err.type === 'entity.too.large') {
    return res.status(413).json({
      error: 'Payload too large. Max upload size exceeded.',
    });
  }

  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({
      error: 'File too large.',
    });
  }

  // Path traversal dari lib/objects.js
  if (err.message && err.message.includes('Path traversal')) {
    return res.status(400).json({ error: 'Invalid key' });
  }

  // SQLite errors
  if (err.code === 'SQLITE_CONSTRAINT_UNIQUE') {
    return res.status(409).json({ error: 'Resource already exists' });
  }

  res.status(err.status || 500).json({
    error: err.expose ? err.message : 'Internal server error',
  });
}

module.exports = { notFound, errorHandler };
