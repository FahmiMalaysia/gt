/**
 * middleware/rateLimit.js — DOS protection via rate limiting
 *
 * Tiga jenis rate limit:
 *  1. generalLimiter — semua API routes (default 100 req/15min per IP)
 *  2. loginLimiter   — POST /auth/login (10 per 15min per IP)
 *  3. signupLimiter  — POST /auth/signup (5 per hour per IP)
 *
 * Free tier hosting (Render/Railway) guna in-memory store.
 * Untuk production scale, swap ke Redis store.
 */

const rateLimit = require('express-rate-limit');

const TRUST_PROXY = process.env.NODE_ENV === 'production';

const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minit
  max: parseInt(process.env.RATE_LIMIT_GENERAL || '100', 10),
  standardHeaders: true,
  legacyHeaders: false,
  trustProxy: TRUST_PROXY,
  message: {
    error: 'Too many requests from this IP, please try again later.',
    retryAfter: '15 minutes',
  },
});

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_LOGIN || '10', 10),
  standardHeaders: true,
  legacyHeaders: false,
  trustProxy: TRUST_PROXY,
  message: {
    error: 'Too many login attempts. Please try again in 15 minutes.',
    retryAfter: '15 minutes',
  },
});

const signupLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 jam
  max: parseInt(process.env.RATE_LIMIT_SIGNUP || '5', 10),
  standardHeaders: true,
  legacyHeaders: false,
  trustProxy: TRUST_PROXY,
  message: {
    error: 'Too many signup attempts. Please try again in 1 hour.',
    retryAfter: '1 hour',
  },
});

const uploadLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minit
  max: 10, // 10 uploads per minit per IP
  standardHeaders: true,
  legacyHeaders: false,
  trustProxy: TRUST_PROXY,
  message: {
    error: 'Too many uploads. Please slow down.',
    retryAfter: '1 minute',
  },
});

module.exports = {
  generalLimiter,
  loginLimiter,
  signupLimiter,
  uploadLimiter,
};
