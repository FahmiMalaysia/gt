/**
 * middleware/auth.js — JWT authentication middleware
 *
 * Add to any route that requires login:
 *   router.post('/protected', authRequired, handler)
 *
 * Optional auth (doesn't fail if no token):
 *   router.get('/public', authOptional, handler)
 */

const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'dev-only-secret-change-me';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';

function signToken(user) {
  return jwt.sign(
    {
      sub: user.id,
      email: user.email,
      username: user.username,
    },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
}

function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (e) {
    return null;
  }
}

/**
 * Extract token from Authorization header.
 * Supports: "Bearer <token>" or raw token
 */
function extractToken(req) {
  const h = req.headers.authorization;
  if (!h) return null;
  const m = /^Bearer\s+(.+)$/i.exec(h);
  return m ? m[1].trim() : h.trim();
}

/** Require valid JWT. Returns 401 if missing/invalid. */
function authRequired(req, res, next) {
  const token = extractToken(req);
  if (!token) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  const payload = verifyToken(token);
  if (!payload) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
  req.user = {
    id: payload.sub,
    email: payload.email,
    username: payload.username,
  };
  next();
}

/** Optional auth — populate req.user if token valid, otherwise continue. */
function authOptional(req, res, next) {
  const token = extractToken(req);
  if (token) {
    const payload = verifyToken(token);
    if (payload) {
      req.user = {
        id: payload.sub,
        email: payload.email,
        username: payload.username,
      };
    }
  }
  next();
}

module.exports = {
  signToken,
  verifyToken,
  extractToken,
  authRequired,
  authOptional,
};
